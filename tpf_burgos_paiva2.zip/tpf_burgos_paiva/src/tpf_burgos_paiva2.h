#ifndef tpf_burgos_paiva2_H_
#define tpf_burgos_paiva2_H_


void inicializarmatriz();
void mostrarmatriz();
void detectar_tip_suma(int detector [12],int y, int x);
int ver_fin_juego(int fin);
void ver_ganador(int ganador[1]);
void print_ganador(int ganador[1]);
int ver_posicion_libre(int y, int x, int ver_coordenas[1]);
int val_sum(int detector[12], int suma);
int val_negativo(int i, int color, int empezar , int a, int y, int x );
void suma_final(int suma, int x, int y, int i, int a, int color, int empezar);
int ver_color(int color);
int ver_posicion_libre_maquina(int y, int x, int ver_coordenas[1]);
int jugada_random(int color);
void reset_det(int detector[12]);
int principal();
int juego(int comp,int empezar,int color);
#endif
