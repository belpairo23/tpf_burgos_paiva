

#ifndef GLOBALES_H_
#define GLOBALES_H_

GtkWidget *windowinicial;
GtkBuilder *constructor;

//ventana incial
GtkWidget*botonsalir;
GtkWidget*botonacerca;
	GtkWidget *botoncreditos;
	GtkWidget *botonjugar;


//ventana creditos
	GtkWidget  *windowcreditos;
	GtkWidget  *botonvolver3;


//ventana acerca

	GtkWidget *windowacerca;
	GtkWidget *botonvolver1;

	GtkWidget *botonestadistica;

	//ventana configuracion
	GtkWidget  *windowconf;
	GtkWidget  *botonvolver2;
	GtkToggleButton  *botonjvj;
	GtkToggleButton  *botoncvj;
	GtkWidget  *botonjugar2;
	GtkToggleButton  *botonrojo	;
	GtkToggleButton  *botonazul;
	GtkToggleButton  *botoncal;
	GtkToggleButton  *botonemp1	;
	GtkToggleButton  *botonemp2;
	GtkToggleButton *botoneal;
	GtkWidget *nombre2;
    GtkWidget *nombre1;
    GtkWidget *turno;
    GtkWidget *label1;
    GtkWidget *label2;


	//ventana juego

	GtkWidget  *windowjuego;
	GtkWidget  *boton00;
	GtkWidget  *boton01;
	GtkWidget  *boton02;
	GtkWidget  *boton03;
	GtkWidget  *boton04;
	GtkWidget  *boton10;
	GtkWidget  *boton11;
	GtkWidget  *boton12;
	GtkWidget  *boton13;
	GtkWidget  *boton14;
	GtkWidget *boton20;
	GtkWidget *boton21;
	GtkWidget *boton22;
	GtkWidget *boton23;
	GtkWidget *boton24;
	GtkWidget *boton30;
	GtkWidget *boton31;
	GtkWidget *boton32;
	GtkWidget *boton33;
	GtkWidget *boton34;
	GtkWidget *boton40;
	GtkWidget *boton41;
	GtkWidget *boton42;
	GtkWidget *boton43;
	GtkWidget *boton44;
	GtkWidget *botonvolver5;
	GtkWidget *botonim1;
	GtkWidget *botonim2;
	GtkWidget *botonim3;
	GtkWidget *botonim4;
	GtkWidget *botonim5;
	GtkWidget *botonim6;
	GtkWidget *botonim7;
	GtkWidget *botonim8;
	GtkWidget *botonim9;
	GtkWidget *botonim10;
	GtkWidget *botonim11;
	GtkWidget *botonim12;
	GtkWidget *im1;
	GtkWidget *im2;
	GtkWidget *im3;
	GtkWidget *im4;
	GtkWidget *im5;
	GtkWidget *im6;
	GtkWidget *im7;
	GtkWidget *im8;
	GtkWidget *im9;
	GtkWidget *im10;
	GtkWidget *im11;
	GtkWidget *im12;
	GtkWidget *text1;
	GtkWidget *text3;
	GtkWidget *text2;

	//venntana error
	GtkWidget *windowerror;
	GtkWidget *botonvolver4;

	//ventana estadistica
	GtkWidget *windowestadistic;
	GtkWidget *botonvolver6;


#define azul 1
#define rojo 0
#define al 4
#define pvp 5
#define pvc 6
#define emp1
	int opcion;
	int opcionc;
	int opcione;
char *tablero[10][10];


#endif /* GLOBALES_H_ */
