#include <gtk/gtk.h>
#include <stdio.h>
#include "globales.h"
#include "tpf_burgos_paiva2.h"

void actualizacion_tablero(char *tablero[10][10],GtkWidget *botones[5][5])
{
    int i,j;
        for(i=0;i<5;i++)     //
        {
                                //Se recorre toda la matriz
            for(j=0;j<5;j++) //
            {
                GtkWidget *imagen_azul=gtk_image_new_from_file("imagenes/dad1a.png");
                GtkWidget *imagen_rojo=gtk_image_new_from_file("imagenes/dad1r.png");
                GtkWidget *imagen_vacio=gtk_image_new_from_file("imagenes/cuadro_blanco.png");
                 if (tablero[i][j][0]=='1')
                 {
                    gtk_button_set_image (GTK_BUTTON(botones[i][j]),imagen_azul);

                 }
                 else if (tablero[i][j][0]=='-1')
                 {
                    gtk_button_set_image (GTK_BUTTON(botones[i][j]),imagen_rojo);
                 }
                 else if(tablero[i][j][0]=='0')
                 {
                    gtk_button_set_image (GTK_BUTTON(botones[i][j]),imagen_vacio);
                 };
            };
        };

        while(gtk_events_pending())
        {
            gtk_main_iteration();
        };
};
//configuracion de los botones

void configuracionmodo1(GtkToggleButton  *boton, gpointer data){

	if (gtk_toggle_button_get_active(boton)){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonjvj),FALSE);
		opcion=1;
	}
}
void configuracionmodo2(GtkToggleButton  *boton, gpointer data){

	if (gtk_toggle_button_get_active(boton)){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botoncvj),FALSE);
		opcion=2;
	}
}
void configuracioncolor1(GtkToggleButton  *boton, gpointer data){

	if (gtk_toggle_button_get_active(boton)){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonrojo),FALSE);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botoncal),FALSE);
		opcionc=1;
	}
}
void configuracioncolor2(GtkToggleButton  *boton, gpointer data){

	if (gtk_toggle_button_get_active(boton)){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonazul),FALSE);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botoncal),FALSE);
		opcionc=2;
	}
}
void configuracioncolor3(GtkToggleButton  *boton, gpointer data){

	if (gtk_toggle_button_get_active(boton)){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonazul),FALSE);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonrojo),FALSE);
		opcionc=3;
	}
}
void configuracionemp1(GtkToggleButton  *boton, gpointer data){

	if (gtk_toggle_button_get_active(boton)){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonemp2),FALSE);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botoneal),FALSE);
		opcione=1;
	}
}
void configuracionemp2(GtkToggleButton  *boton, gpointer data){

	if (gtk_toggle_button_get_active(boton)){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonemp1),FALSE);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botoneal),FALSE);
		opcione=2;
	}
}
void configuracionemp3(GtkToggleButton  *boton, gpointer data){

	if (gtk_toggle_button_get_active(boton)){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonemp2),FALSE);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonemp1),FALSE);
		opcione=3;
	}
}

//se usa para abrir la ventana

void openwindow(GtkWidget *widget, gpointer user_data) {
    // Ocultar la ventana que contiene el botón presionado
    gtk_widget_hide(gtk_widget_get_toplevel(widget));

    // Mostrar la ventana que recibió como parámetro
    gtk_widget_show_all(GTK_WIDGET(user_data));
}

//conecta lo seleccionado con el codigo de juego
void inicio_juego(GtkWidget *W){
	principal(opcion,opcionc,opcione); //mandar configuraciones
	 gtk_widget_hide(windowconf);
	 gtk_widget_show_all(windowjuego);


}
//se asigna los botones
void asignacion_botones(GtkWidget *boton [5][5], GtkBuilder *constructor){
	int i, j,cont=0;
	gchar cadena[10];
	for(i=1;i<5;i++){
		for(i=1;i<5;i++){
				sprintf(cadena,"%d",cont);
				boton[i][j]=GTK_WIDGET(gtk_builder_get_object(constructor,cadena));
				cont++;
			}
	}
}

int main(int argc, char *argv[]) {
    // Inicialización de GTK
    gtk_init(&argc, &argv);

    // Crear constructor y cargar interfaz desde el archivo Glade
  GtkBuilder  *constructor = gtk_builder_new_from_file("tpf_burgos_paiva.glade");

    if (constructor == NULL) {
        printf("Error al cargar el archivo Glade\n");
        return 1; // Salir con error
    }

    // Obtener objetos de las ventanas y botones
    GtkWidget *windowinicial = GTK_WIDGET(gtk_builder_get_object(constructor, "ventana_inicial"));
    GtkWidget *windowcreditos = GTK_WIDGET(gtk_builder_get_object(constructor, "ventana_creditos"));
    windowjuego = GTK_WIDGET(gtk_builder_get_object(constructor, "ventana_juego"));
    GtkWidget *windowacerca = GTK_WIDGET(gtk_builder_get_object(constructor, "ventana_acerca"));
    windowconf = GTK_WIDGET(gtk_builder_get_object(constructor, "ventana_configuracion"));
    GtkWidget *windowestadistic = GTK_WIDGET(gtk_builder_get_object(constructor, "ventana_estadistic"));



    // Cargar imágenes en los widgets GtkImage (rutas relativas)


    GtkWidget *botonjugar = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_jugar"));
    GtkWidget *botoncreditos = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_creditos"));
    GtkWidget *botonacerca = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_acerca"));
    GtkWidget *botonsalir = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_salir"));
    GtkWidget *botonestadistica = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_estadisticas"));
    GtkWidget *botonjugar2 = GTK_WIDGET(gtk_builder_get_object(constructor, "botonjugar2"));
    botonrojo = GTK_TOGGLE_BUTTON(gtk_builder_get_object(constructor, "botonrojo"));
    botonjvj=GTK_TOGGLE_BUTTON(gtk_builder_get_object(constructor, "botonjvj"));
    botoncvj=GTK_TOGGLE_BUTTON(gtk_builder_get_object(constructor, "botoncvj"));
    botonazul=GTK_TOGGLE_BUTTON(gtk_builder_get_object(constructor, "botonazul"));
    botoncal=GTK_TOGGLE_BUTTON(gtk_builder_get_object(constructor, "botoncal"));
    botonemp1=GTK_TOGGLE_BUTTON(gtk_builder_get_object(constructor, "botonej1"));
    botonemp2=GTK_TOGGLE_BUTTON(gtk_builder_get_object(constructor, "botonej2"));
    botoneal=GTK_TOGGLE_BUTTON(gtk_builder_get_object(constructor, "botonea"));

//conexion d los botones para cambiar ventanas
    g_signal_connect(botonjugar, "clicked", G_CALLBACK(openwindow), windowconf);
    g_signal_connect(botoncreditos, "clicked", G_CALLBACK(openwindow), windowcreditos);
    g_signal_connect(botonacerca, "clicked", G_CALLBACK(openwindow), windowacerca);
    g_signal_connect(botonestadistica, "clicked", G_CALLBACK(openwindow), windowestadistic);
    g_signal_connect(botonjugar2, "clicked", G_CALLBACK(inicio_juego), windowjuego);

    g_signal_connect(botonsalir, "clicked", G_CALLBACK(gtk_main_quit), NULL);

    GtkWidget *botonvolver1 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_volver1"));
    GtkWidget *botonvolver2 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_volver2"));
    GtkWidget *botonvolver3 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_volver3"));
    GtkWidget *botonvolver4 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_volver4"));
    GtkWidget *botonvolver5 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_volver5"));
    GtkWidget *botonvolver6 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_volver6"));
//opcion para volver
    g_signal_connect(botonvolver1, "clicked", G_CALLBACK(openwindow), windowinicial);
    g_signal_connect(botonvolver2, "clicked", G_CALLBACK(openwindow), windowinicial);
    g_signal_connect(botonvolver3, "clicked", G_CALLBACK(openwindow), windowinicial);
    g_signal_connect(botonvolver4, "clicked", G_CALLBACK(openwindow), windowinicial);
    g_signal_connect(botonvolver5, "clicked", G_CALLBACK(openwindow), windowinicial);
    g_signal_connect(botonvolver6, "clicked", G_CALLBACK(openwindow), windowinicial);

//prepara la configuracion del juego
    g_signal_connect(botonazul, "toggled", G_CALLBACK(configuracioncolor1), windowconf );
    g_signal_connect(botonrojo, "toggled", G_CALLBACK(configuracioncolor2), windowconf );
    g_signal_connect(botoncal, "toggled", G_CALLBACK(configuracioncolor3), windowconf );
    g_signal_connect(botonjvj, "toggled", G_CALLBACK(configuracionmodo2), windowconf );
    g_signal_connect(botoncvj, "toggled", G_CALLBACK(configuracionmodo1), windowconf );
    g_signal_connect(botonemp1, "toggled", G_CALLBACK(configuracionemp1), windowconf );
    g_signal_connect(botonemp2, "toggled", G_CALLBACK(configuracionemp2), windowconf );
    g_signal_connect(botoneal, "toggled", G_CALLBACK(configuracionemp3), windowconf );



    const char *nombrej1 = gtk_entry_get_text(GTK_ENTRY(nombre1));

    if (nombrej1 == NULL || strcmp(nombrej1, "") == 0) {
        nombrej1= "Player";
    }
    const char *nombrej2 = gtk_entry_get_text(GTK_ENTRY(nombre2));

       if (nombrej2 == NULL || strcmp(nombrej2, "") == 0) {
           nombrej2 = "Player";
       }



    gtk_widget_show_all(windowinicial);

    // Ejecutar el bucle principal de GTK
    gtk_main();

    return 0;

}
