#ifndef tpf_burgos_paiva2_H_
#define tpf_burgos_paiva2_H_


void inicializarmatriz();
void mostrarmatriz();
void detectar_tip_suma();
void casillasgtk();
void detectar_tip_suma_maquina();
int ver_fin_juego(int fin);
void ver_ganador(int ganador[1]);
void print_ganador();
int ver_posicion_libre(int y, int x, int ver_coordenas[1]);
int val_sum(int detector[12], int suma);
int val_negativo(int i, int color, int empezar , int a, int y, int x );
void suma_final();
int ver_color(int color);
int ver_posicion_libre_maquina(int y, int x, int ver_coordenas[1]);
int jugada_random(int color);
void reset_det();
int principal();
int ver_5();
void ver_captura();
void turno_boton();
void input_coordenada(int valor);
void activar_opciones();
void mirar_captura();
void presionar(GtkWidget *boton, gpointer *data);
void captura(GtkWidget *boton, gpointer *data);
void activar_botones();

#endif
