/*
 ============================================================================
 Name        : pruebas_archivos.c
 Author      : Lucas Burgos
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */
#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
 int comp=0;
 int control;
 int opcion;
 int suma;
 int c;
 int cont;
 int x;
 int y;
 int color = 0;
 int variable =1;
 int a;
 int color;
 int empezar = 0;
 int matriz [10][10];
 int detector [12];
 int ver_coordenadas [2];
 int vector[12];
 int casillas[160];
 int ganador[1];
 char buffer1[50];
 char buffer2[50];




 GtkLabel *estadisticas_empate;
 GtkGrid *grilla_captura;
 GtkGrid *grid;  // Declarar el Grid globalmente
 GtkWidget *windowinicial;
 GtkBuilder *constructor;
 GtkEntry *entry1;
 const gchar *texto1;
 const gchar *texto2;
 //ventana incial
 GtkWidget*boton_salir;
 GtkWidget*botonacerca;
 	GtkWidget *botoncreditos;
 	GtkWidget *botonjugar;
GtkWidget *boton_terminar;
	GtkWidget *boton_continuar;
 //ventana creditos
 	GtkWidget  *windowcreditos;
 	GtkWidget  *botonvolver3;
 	GtkWidget*boton_salir2;
 	GtkWidget *windowganador;

 //ventana acerca

 	GtkWidget *windowacerca;
 	GtkWidget *botonvolver1;

 	GtkWidget *botonestadistica;

 	//ventana configuracion
 	GtkWidget  *windowconf;
 	GtkWidget  *botonvolver2;
 	GtkToggleButton  *botonjvj;
 	GtkToggleButton  *botoncvj;
 	GtkToggleButton  *botoncvc;
 	GtkWidget  *botonjugar2;
 	GtkToggleButton  *botonrojo	;
 	GtkToggleButton  *botonazul;
 	GtkToggleButton  *botoncal;
 	GtkToggleButton  *botonemp1	;
 	GtkToggleButton  *botonemp2;
 	GtkToggleButton *botoneal;
 	GtkLabel *nombre2;
    GtkLabel *nombre1;
    GtkWidget *boton_turno;

    GtkEntry *entry2 ;



 	//ventana juego

 	GtkWidget  *windowjuego;
 	GtkWidget *botonvolver5;
 	GtkWidget *botoncruz;
 	GtkWidget *boton_vacio_arriba;
 	GtkWidget *boton_vacio_abajo;
 	GtkWidget *boton_vacio_izquierda;
 	GtkWidget *boton_vacio_derecha;
 	GtkWidget *boton_vacio_abajo_derecha;
 	GtkWidget *boton_vacio_abajo_izquierda;
 	GtkWidget *boton_vacio_arriba_izquierda;
 	GtkWidget *boton_vacio_arriba_derecha;
 	GtkWidget *boton_vacio_arriba_abajo;
 	GtkWidget *boton_arriba_abajo;
 	GtkWidget  *BOTON1;
 	GtkWidget *BOTON2;
 	GtkWidget *BOTON3;
 	GtkWidget *BOTON4;
 	GtkWidget *BOTON5;
 	GtkWidget *BOTON6;
 	GtkWidget *BOTON7;
 	GtkWidget *BOTON8;
 	GtkWidget *BOTON9;
 	GtkWidget *BOTON10;
 	GtkWidget *BOTON11;
     GtkWidget *BOTON12;
 	GtkWidget *BOTON13;
 	GtkWidget *BOTON14;
 	GtkWidget  *BOTON15;
 	GtkWidget  *BOTON16;
 	GtkWidget  *BOTON17;
 	GtkWidget	*BOTON18;
 	GtkWidget *BOTON19;
 	GtkWidget *BOTON20;
 	GtkWidget *BOTON21;
 	GtkWidget *BOTON22;
 	GtkWidget *BOTON23;
 	GtkWidget *BOTON24;
    GtkWidget	*BOTON25;
    GtkWidget *imagen1a;
    GtkLabel *label_ganador;
	GtkLabel *label_estadisticas;
	GtkLabel *estadisticas_ganador;
	GtkLabel *estadisticas_perdedor;
 	//venntana error
 	GtkWidget *windowerror;
 	GtkWidget *botonvolver4;


 	//ventana estadistica
 	GtkWidget *windowestadistic;
 	GtkWidget *botonvolver6;
 	GtkWidget *boton_jugar_3;
 	GtkWidget *botonvolver7;


//Se puso una funcion que guardade en un vector  cuantos dados de cada color hay en el tablero  (ver_ganador)
//Se puso una funcion que con el vector de dados imprime la cantidad de dados y tambien ve quien gano o si hubo un empate (print_ganador)
//Habia un error cuando debido que al sacar el vector detector[12] se hacia un return de todos los datos a la posicion 12 eso hacia que no funcion el la condicion de sumar si es menor a 7
//Tambien se hizo una funcion que resetea los valores de detector[12] para evitar
//Se hizo un void para que retorne correctamente los valores del vector director[12]
//Se puso un if(acabar_juego == 1){ } tambien entre las jugadas del cpu porque podia resultar el caso que el tablero se llenara e igual se ejecutase la jugada del Jugador


void inicializarmatriz(){

  for(int i = 0; i < 5; i++){
      for(int j = 0; j < 5; j++){
        matriz[i][j] = 0;
      }
    }

}
void turno_boton(){


				gchar *filename;


				if((c % 2) == 0){


					filename=g_strdup_printf("imagenes/turno_2.png"); //turbno rojo



				}

				else{

					filename=g_strdup_printf("imagenes/turno_1.png"); // turno azul

							}

				gtk_button_set_image(GTK_BUTTON(boton_turno),gtk_image_new_from_file(filename));

				g_free(filename);


}
void casillasgtk(){
	int rojo;
	for (int i=0; i < 5;i++){

		for (int j=0; j < 5;j++){

			gchar *filename;

			GtkWidget *boton= gtk_grid_get_child_at(GTK_GRID(grid),j,i);

			if(matriz[i][j]<0){
				rojo = abs(matriz[i][j]) -1;

				filename=g_strdup_printf("imagenes/r_%d.png",rojo);



			}

			if(matriz[i][j]> 0){

				filename=g_strdup_printf("imagenes/a_%d.png",matriz[i][j]-1);

						}

			if(matriz[i][j] == 0){

				filename=g_strdup("imagenes/carta_atras.png");

			}

			gtk_button_set_image(GTK_BUTTON(boton),gtk_image_new_from_file(filename));

			g_free(filename);

		}

	}

}
void mostrarmatriz(){

  printf("\n");
  printf("+");
  for(int i = 0; i < 5; i++){
    printf("---+");
    if(i == 5-1)
      printf("\n");
  }
  for(int i = 0; i < 5; i++){

    printf("|");
    for(int j = 0; j < 5; j++){

      printf(" %d |", matriz[i][j]);
    }
    printf("\n");
    printf("+");
    for(int i = 0; i < 5; i++){
      printf("---+");
      if(i == 5-1)
        printf("\n");
    }
  }
  printf("\n");
}


//Detecta la cantidda de opciones de suma hay ya que cada vez que entra en un if este aumenta. Tambien se guarda en un vector que clase de suma es dependiendo en donde entre va a guardar un numero que es el tipo de suma
void detectar_tip_suma(){



	  int cant_pos = 0;
	  detector[1] = 0;
	  //Sumamos +1 porque queremos la posicion [0] libre para luego colocarle el valor de cant_post
	  // suma en cruz
	  if(matriz[y-1][x] != 0 && matriz[y+1][x] != 0 && matriz[y][x-1] != 0 && matriz[y][x+1] != 0 && (abs(matriz[y-1][x]) + abs(matriz[y+1][x]) + abs(matriz[y][x-1]) + abs(matriz[y][x+1]) )<= 6 && y-1>= 0 && y+1 <= 4 && x-1>= 0 && x+1 <= 4){
	    detector[cant_pos+1] = 1;
	    ++cant_pos;

	  }
	  //Grupo autito
	  //vacio arriba
	  if( matriz[y][x-1] != 0 && matriz[y+1][x] != 0  && matriz[y][x+1] != 0 && abs(matriz[y][x-1]) + abs(matriz[y+1][x]) + abs(matriz[y][x+1]) <= 6 && y+1 <= 4 && x-1>= 0 && x+1 <= 4){
	    detector[cant_pos+1] = 2;
	    ++cant_pos;

	  }
	  //vacio abajo
	  if(matriz[y-1][x] != 0  &&  matriz[y][x-1] != 0 && matriz[y][x+1] != 0 && abs(matriz[y-1][x])  + abs(matriz[y][x-1]) + abs(matriz[y][x+1]) <= 6 && y-1>= 0 && x-1>= 0 && x+1 <= 4){
	    detector[cant_pos+1] = 3;
	    ++cant_pos;

	  }
	  //vacio izquieda
	  if(matriz[y-1][x] != 0 && matriz[y+1][x] != 0 && matriz[y][x+1] != 0 && abs(matriz[y-1][x]) + abs(matriz[y+1][x])  + abs(matriz[y][x+1]) <= 6  && y-1>= 0 && y-1>= 0  && x+1 <= 4){
	    detector[cant_pos+1] = 4;
	    ++cant_pos;

	  }
	  //vacio derecha
	  if(matriz[y-1][x] != 0 && matriz[y+1][x] != 0 && matriz[y][x-1] != 0  && abs(matriz[y-1][x]) + abs(matriz[y+1][x]) + abs(matriz[y][x-1]) <= 6  && y+1>= 0 && y-1>= 0 && x-1>= 0){
	    detector[cant_pos+1] = 5;
	    ++cant_pos;

	  }
	  //Grupo esquina
	  //izquieda arriba
	  if(matriz[y-1][x] != 0  && matriz[y][x-1] != 0  && abs(matriz[y-1][x]) + abs(matriz[y][x-1]) <= 6 && y-1>= 0 && x-1>= 0 ){
	    detector[cant_pos+1] = 6;
	    ++cant_pos;

	  }
	  //derecha arriba
	  if(matriz[y-1][x] != 0  && matriz[y][x+1] != 0 && abs(matriz[y-1][x]) + abs(matriz[y][x+1]) <= 6  && y-1>= 0   && x+1 <= 4){
	    detector[cant_pos+1] = 7;
	    ++cant_pos;

	  }
	  // izquieda abajo
	  if( matriz[y+1][x] != 0 && matriz[y][x-1] != 0 &&   abs(matriz[y+1][x]) + abs(matriz[y][x-1]) <= 6 && y+1<= 4 && x-1>= 0){
	    detector[cant_pos+1] = 8;
	    ++cant_pos;

	  }
	  //derecha abajo
	  if(matriz[y+1][x] != 0 && matriz[y][x+1] != 0  && abs(matriz[y+1][x])  + abs(matriz[y][x+1]) <= 6 && y+1<= 4 && x+1 <= 4){
	    detector[cant_pos+1] = 9;
	    ++cant_pos;

	  }
	  //Grupo palito
	  //izquieda-derecha
	  if(  matriz[y][x-1] != 0 && matriz[y][x+1] != 0 && abs(matriz[y][x-1]) + abs(matriz[y][x+1]) <= 6 &&  x-1>= 0 && x+1 <= 4){
	    detector[cant_pos+1] = 10;
	    ++cant_pos;

	  }
	  //arriba-abajo
	  if(matriz[y-1][x] != 0 && matriz[y+1][x] != 0 && abs(matriz[y-1][x]) + abs(matriz[y+1][x])  <= 6 && y-1>= 0 && y+1 <= 4){
	    detector[cant_pos+1] = 11;
	    ++cant_pos;

	  }
	  if( cant_pos == 0){
	    detector[1] = 12;
	  }
	  // Aca alojamos la cantidad de opciones de suma en la primera posicion de detector
	  // Se hace esto por que probablemente necesite esta variable en otras funciones y solo puedo retornar una variable en c, asi que intento poner todos los datos posibles en detector[]
	  detector[0] = cant_pos;



	  // Si detector es hay mas opciones te va tirar distintos prints de tus posibles sumas
	  // Empieza en 1 porque en la posicion 0 esta la cantidad de opciones
	  // El por hace que salte a cada una de las opciones

}

void detectar_tip_suma_maquina(){
  int cant_pos = 0;
  detector[1] = 0;
  //Sumamos +1 porque queremos la posicion [0] libre para luego colocarle el valor de cant_post
  // suma en cruz
  if(matriz[y-1][x] != 0 && matriz[y+1][x] != 0 && matriz[y][x-1] != 0 && matriz[y][x+1] != 0 && (abs(matriz[y-1][x]) + abs(matriz[y+1][x]) + abs(matriz[y][x-1]) + abs(matriz[y][x+1]) )<= 6 && y-1>= 0 && y+1 <= 4 && x-1>= 0 && x+1 <= 4){
    detector[cant_pos] = 1;
    ++cant_pos;
  }
  //Grupo autito
  //vacio arriba
  if( matriz[y][x-1] && matriz[y+1][x] != 0  && matriz[y][x+1] != 0 && abs(matriz[y][x-1]) + abs(matriz[y+1][x]) + abs(matriz[y][x+1]) <= 6  && y+1 <= 4 && x-1>= 0 && x+1 <= 4){
    detector[cant_pos] = 2;
    ++cant_pos;
  }
  //vacio abajo
  if(matriz[y-1][x] != 0  &&  matriz[y][x-1] != 0 && matriz[y][x+1] != 0 && abs(matriz[y-1][x])  + abs(matriz[y][x-1]) + abs(matriz[y][x+1]) <= 6 && y+1>= 4 && x-1>= 0 && x+1 <= 4){
    detector[cant_pos] = 3;
    ++cant_pos;
  }
  //vacio izquieda
  if(matriz[y-1][x] != 0 && matriz[y+1][x] != 0 && matriz[y][x+1] != 0 && abs(matriz[y-1][x]) + abs(matriz[y+1][x])  + abs(matriz[y][x+1]) <= 6 && y-1>= 0 && y-1>= 0  && x+1 <= 4){
    detector[cant_pos] = 4;
    ++cant_pos;
  }
  //vacio derecha
  if(matriz[y-1][x] != 0 && matriz[y+1][x] != 0 && matriz[y][x-1] != 0  && abs(matriz[y-1][x]) + abs(matriz[y+1][x]) + abs(matriz[y][x-1]) <= 6 && y+1>= 0 && y-1>= 0 && x-1>= 0 ){
    detector[cant_pos] = 5;
    ++cant_pos;
  }
  //Grupo esquina
  //izquieda arriba
  if(matriz[y-1][x] != 0  && matriz[y][x-1] != 0  && abs(matriz[y-1][x]) + abs(matriz[y][x-1]) <= 6 && y-1>= 0 && x-1>= 0){
    detector[cant_pos] = 6;
    ++cant_pos;
  }
  //derecha arriba
  if(matriz[y-1][x] != 0  && matriz[y][x+1] != 0 && abs(matriz[y-1][x]) + abs(matriz[y][x+1]) && y-1>= 0   && x+1 <= 4){
    detector[cant_pos] = 7;
    ++cant_pos;
  }
  // izquieda abajo
  if( matriz[y+1][x] != 0 && matriz[y][x-1] != 0 &&   abs(matriz[y+1][x]) + abs(matriz[y][x-1]) <= 6 && y+1>= 4 && x-1>= 0 ){
    detector[cant_pos] = 8;
    ++cant_pos;
  }
  //derecha abajo
  if(matriz[y+1][x] != 0 && matriz[y][x+1] != 0  && abs(matriz[y+1][x])  + abs(matriz[y][x+1]) <= 6 && y+1 <= 4 && x+1 <= 4){
    detector[cant_pos] = 9;
    ++cant_pos;
  }
  //Grupo palito
  //izquieda-derecha
  if(  matriz[y][x-1] != 0 && matriz[y][x+1] != 0 && abs(matriz[y][x-1]) + abs(matriz[y][x+1]) <= 6 &&  x-1>= 0 && x+1 <= 4){
    detector[cant_pos] = 10;
    ++cant_pos;
  }
  //arriba-abajo
  if(matriz[y-1][x] != 0 && matriz[y+1][x] != 0 && abs(matriz[y-1][x]) + abs(matriz[y+1][x])  <= 6 && y-1>= 0 && y+1 <= 4){
    detector[cant_pos] = 11;
    ++cant_pos;
  }
  if( cant_pos == 0){
    detector[1] = 12;
  }
  // Aca alojamos la cantidad de opciones de suma en la primera posicion de detector
  // Se hace esto por que probablemente necesite esta variable en otras funciones y solo puedo retornar una variable en c, asi que intento poner todos los datos posibles en detector[]

}


//La funcion recorre toda la matriz y va sumando a cont siempre y cuando no encientre 0
//Si cont llega a valer 25 (la matriz es 5x5 eso significa que no hay espacios vacios en la matriz) fin va valer 1
//La utilidad de esto es que todo el codigo va estar en un while que mientras fin no sea distinto a 0 se va a volver a ejecutarse, esta funcion cambia el valor de fin si es que no hay espacion vacios en la matriz
int ver_fin_juego(int fin){
  int cont = 0;

  for(int i = 0; i < 5; i++){
      for(int j = 0; j < 5; j++){
        if(matriz[i][j] != 0){ ++cont;}
      }
    }
  if(cont == 25){ fin = 1;}
  return fin;
}
//Almacena en la variabel ganador la cantidad de dadods azules y rojos
void ver_ganador(){
  int cont = 0;
  int cont2 = 0;

  for(int i = 0; i < 5; i++){
      for(int j = 0; j < 5; j++){
        if(matriz[i][j] > 0){ ++cont;}
        if(matriz[i][j] < 0){ ++cont2;}
      }
    }
    ganador[0] = cont;
    ganador[1] = cont2;

}
//Compara con las cantidades almacenadas en ganador para ver quien gano o si hubo un empate



// Esta funcion realizara la suma y vaciara los valores adyacentes
//El caso de suma sera seleccionado en funcion del valor

int val_negativo(){
	int i;
	i = c;
  if( (color == 1 && empezar == 1)||( color == 2 && empezar == 2 ) ){
    if(i % 2 == 1 ){
      matriz[y][x] = -a;
    }
    else{
      matriz[y][x] = a;
    }
  }
  if( (color == 2 && empezar == 1)||( color == 1 && empezar == 2 ) ){
      if(i % 2 == 0 ){
        matriz[y][x] = -a;
      }
      else{
        matriz[y][x] = a;
      }
    }
  return a;
}
void suma_final(){

  //sumar en forma de cruz
  if( suma == 1){
    a = abs(matriz[y-1][x]) + abs(matriz[y+1][x]) + abs(matriz[y][x-1]) + abs(matriz[y][x+1]);
    a = val_negativo( );
    matriz[y-1][x] = 0;
    matriz[y+1][x] = 0;
    matriz[y][x+1] = 0;
    matriz[y][x-1] = 0;
  }
  //Grupo auto
  //vacio arriba
  if( suma == 2){
    a =  abs(matriz[y+1][x]) + abs(matriz[y][x-1]) + abs(matriz[y][x+1]);
    a = val_negativo( );
    matriz[y+1][x] = 0;
    matriz[y][x+1] = 0;
    matriz[y][x-1] = 0;
  }
  //vacio abajo
  if( suma == 3){
    a = abs(matriz[y-1][x]) + abs(matriz[y][x-1]) + abs(matriz[y][x+1]);
    a = val_negativo( );
    matriz[y-1][x] = 0;
    matriz[y][x+1] = 0;
    matriz[y][x-1] = 0;
  }
  //vacio izquierda
  if( suma == 4){
    a = abs(matriz[y-1][x]) + abs(matriz[y+1][x]) + abs(matriz[y][x+1]);
    a = val_negativo();
    matriz[y-1][x] = 0;
    matriz[y+1][x] = 0;
    matriz[y][x+1] = 0;
  }
  //vacio derecha
  if( suma == 5 ){
    a = abs(matriz[y-1][x]) + abs(matriz[y+1][x]) + abs(matriz[y][x-1]) ;
    a = val_negativo( );
    matriz[y-1][x] = 0;
    matriz[y+1][x] = 0;

    matriz[y][x-1] = 0;
  }
  //Grupo esquina
  //arriba-izquierda
  if( suma == 6){
    a = abs(matriz[y-1][x]) + abs(matriz[y][x-1]);
    a = val_negativo();
    matriz[y-1][x] = 0;
    matriz[y][x-1] = 0;
  }
  //arriba-derecha
  if( suma == 7){
    a = abs(matriz[y-1][x])  + abs(matriz[y][x+1]);
    a = val_negativo( );
    matriz[y-1][x] = 0;
    matriz[y][x+1] = 0;
  }
  //abajo-izquieda
  if( suma == 8){
    a =  abs(matriz[y+1][x]) + abs(matriz[y][x-1]);
    a = val_negativo( );
    matriz[y+1][x] = 0;
    matriz[y][x-1] = 0;
  }
  //abajo-derecha
  if( suma == 9){
    a =  abs(matriz[y+1][x]) + abs(matriz[y][x+1]);
    a = val_negativo( );
    matriz[y+1][x] = 0;
    matriz[y][x+1] = 0;
  }
  //Grupo Palito
  //izquierda-derecha
  if( suma == 10){
    a = abs(matriz[y][x-1]) + abs(matriz[y][x+1]);
    a = val_negativo( );
    matriz[y][x+1] = 0;
    matriz[y][x-1] = 0;
  }
  //arriba-abajo
  if( suma == 11){
    a = abs(matriz[y-1][x]) + abs(matriz[y+1][x]) ;
    a = val_negativo( );
    matriz[y-1][x] = 0;
    matriz[y+1][x] = 0;
  }
  //No se puede sumar
  if(suma == 12){
    a = 1;
    a = val_negativo( );
  }
}

//Esta funcion hace que los valores que se sobrescriban en negativo o positivo dependiendo que que conjunto de opciones hayas elegido

//Cambiar aca Belen
void ver_posicion_libre_maquina(){

  while(matriz[y][x] != 0  ){
      srand(time(NULL));

              x = rand() % 5;
              y = rand() % 5;
  }
  ver_coordenadas[0] = x;
  ver_coordenadas[1] = y;
}

int jugada_random(){

    if(color == 3){
        srand(time(NULL));
        color = (rand() %2) +1 ;

    }

    return color;
}
void reset_det(){

    for(int i = 0; i < 12; i++){
        detector[i] = 0;
    }
}


//la funcion guarda la casillas donde no se pueden poner un dado sin que tu rival capture el numero 6
int ver_5(){

    int pos_5[25];
    int cont = 1;
    int cont2 = 0;

    for(int i = 0; i <= 4; ++i){
        for(int j = 0; j <= 4; ++j){
            if(matriz[i][j] == 5){
                pos_5[cont] = i;
                ++cont;
                pos_5[cont] = j;
                ++cont;
                ++cont2;
            }
        }
    }

    for(int i = 0; i < cont2; ++i){

        //derecha
        casillas[1 +i*16] = pos_5[i*2+1];
        casillas[2 +i*16] = pos_5[i*2 + 2]+2;
        //izquieda
        casillas[3 +i*16] = pos_5[i*2+1];
        casillas[4 +i*16] = pos_5[i*2 + 2]-2;
        //arriba
        casillas[5 +i*16] = pos_5[i*2+1]-2;
        casillas[6 +i*16] = pos_5[i*2 + 2];
        //abajo
        casillas[7 +i*16] = pos_5[i*2+1]+2;
        casillas[8 +i*16] = pos_5[i*2 + 2];
        //abajo derecha
        casillas[9 +i*16] = pos_5[i*2+1]+1;
        casillas[10 +i*16] = pos_5[i*2 + 2]+1;
        //abajo izquuierda
        casillas[11 +i*16] = pos_5[i*2+1]+1;
        casillas[12 +i*16] = pos_5[i*2 + 2]-1;
        //arriba derecha
        casillas[13 +i*16] = pos_5[i*2+1]-1;
        casillas[14 +i*16] = pos_5[i*2 + 2]+1;
        //arriba izquierda
        casillas[15 +i*16] = pos_5[i*2+1]-1;
        casillas[16 +i*16] = pos_5[i*2 + 2]-1;
    }
    return cont2;
}

//Mira las casillas que puede capturar si es que no son casillas donde puedan capturar el 6 y si no se cumple ninguna de esas condiciones lo hace aleatorio
int ver_casilla(int X, int Y, int cont,int casillas[160] ){
    //variable que si es 0 el la posicion que se quiere comer no es la misma que las casillas donde no se pueden poner
    int misma = 0;
    for (int i = 0; i < cont*8 ; i++) {
        if (Y ==  casillas[i*2 +1] && X == casillas[i*2 + 2] && matriz[Y][X] == 0){
            misma = 1;
            break;

        }
    }

    if(misma == 0 ){
        ver_coordenadas[1] = Y;
        ver_coordenadas[0] = X;
        misma = 0;
    }


    return misma;
}

void ver_captura(){

	int X;
	int Y;
	int misma = 1;
	x = 0;
	y = 0;

  for(y = 0; y< 4; y++){
    for(x = 0; x< 4; x++){
    // palito izquieda
    if(matriz[y][x-2] != 0  && (x -2) >= 0 && abs(matriz[y][x]) + abs(matriz[y][x-2]) <= 6  && matriz[y][x] != 0 && abs(matriz[y][x]) != 6 && x-1>= 0){

        X = x-1;
        Y = y;
      misma = ver_casilla(X,Y,cont,casillas );
        if((abs(matriz[y][x-2]) == 5  && abs(matriz[Y][X]) == 1) || (abs(matriz[y][x-2]) == 1  && abs(matriz[Y][X]) == 5) ){

          ver_coordenadas[1] = Y;
          ver_coordenadas[0] = X;
          misma = 0;

        }

    }

    //palito derecha
    if(matriz[y][x+2] != 0 && (x+2)<= 4 && abs(matriz[y][x]) + abs(matriz[y][x-2]) <= 6  && matriz[y][x] != 0 && abs(matriz[y][x]) != 6 && x+1 <=4){

        X = x+1;
        Y = y;

        if(misma == 1 && matriz[Y][X] == 0 ){
          misma = ver_casilla(X,Y,cont,casillas );
          if((abs(matriz[y][x+2]) == 5 && abs(matriz[y][x+1]) == 0) || (abs(matriz[y][x+2]) == 5 && abs(matriz[y][x+1]) == 0)){
            ver_coordenadas[1] = Y;
            ver_coordenadas[0] = X;
            misma = 0;
          }

        }

    }

    //palito arriba
    if(matriz[y-2][x] != 0 && (y-2) >= 0 && abs(matriz[y][x]) + abs(matriz[y-2][x]) <= 6 && matriz[y][x] != 0 && abs(matriz[y][x]) != 6 && y-1>= 4){

        X = x;
        Y = y-1;

        if(misma == 1 && matriz[Y][X] == 0){
          misma = ver_casilla(X,Y,cont,casillas );
          if((abs(matriz[y-2][x]) == 5  && abs(matriz[y-1][x]) == 1) || (abs(matriz[y-2][x]) == 1  && abs(matriz[y-1][x]) == 5)){
            ver_coordenadas[1] = Y;
            ver_coordenadas[0] = X;
            misma = 0;
          }

        }
    }

    //palito abajo
    if(matriz[y+2][x] != 0 && (y+2) <= 4 && abs(matriz[y][x]) + abs(matriz[y+2][x]) <= 6  && matriz[y][x] != 0 && abs(matriz[y][x]) != 6 && y+1<= 4){

        X = x;
        Y = y+1;

        if(misma == 1 && matriz[Y][X] == 0){
          misma = ver_casilla(X,Y,cont,casillas );
          if((abs(matriz[y+2][x]) == 5 && abs(matriz[y+1][x]) == 1) || (abs(matriz[y+2][x]) == 1 && abs(matriz[y+1][x]) == 5)){
            ver_coordenadas[1] = Y;
            ver_coordenadas[0] = X;
            misma = 0;
          }

        }
    }

    //esquina arriba-arriba y arriba-abajo
    if(matriz[y-1][x-1] != 0 && y-1 >= 0 && x-1 >= 0 && abs(matriz[y][x]) + abs(matriz[y-1][x-1]) <= 6  && matriz[y][x] != 0 && abs(matriz[y][x]) != 6 && y-1>= 0){

        X = x;
        Y = y-1;

        if(misma == 1 && matriz[Y][X] == 0){
          misma = ver_casilla(X,Y,cont,casillas );
          if( (abs(matriz[y-1][x-1]) == 5 && abs(matriz[y-1][x]) == 1) && (abs(matriz[y-1][x-1]) == 1 && abs(matriz[y-1][x]) == 5) ){
            ver_coordenadas[1] = Y;
            ver_coordenadas[0] = X;
            misma = 0;
          }

        }


        X = x-1;
        Y = y;

        if(misma == 1 && matriz[Y][X] == 0 ){
          misma = ver_casilla(X,Y,cont,casillas  );
          if((abs(matriz[y-1][x-1]) == 5 && abs(matriz[y][x-1]) == 1) &&  (abs(matriz[y-1][x-1]) == 1 && abs(matriz[y][x-1]) == 5)  ){
            ver_coordenadas[1] = Y;
            ver_coordenadas[0] = X;
            misma = 0;
          }

        }
    }



    //esquina abajo-arriba y abajo-abajo
    if(matriz[y+1][x+1] != 0 && y+1 <= 4 && x+1 <= 4 &&  abs(matriz[y][x]) + abs(matriz[y+1][x+1]) <= 6  && matriz[y][x] != 0 && abs(matriz[y][x]) != 6 && x+1<=4){

        X = x+1;
        Y = y;

        if(misma == 1 && matriz[Y][X] == 0){
          misma = ver_casilla(X,Y,cont,casillas);
          if((abs(matriz[y+1][x+1]) == 5 && abs(matriz[y][x+1] == 1)) || (abs(matriz[y+1][x+1]) == 1 && abs(matriz[y][x+1] == 5)) ){
            ver_coordenadas[1] = Y;
            ver_coordenadas[0] = X;
            misma = 0;
          }
            ;
        }


        X = x;
        Y = y+1;

        if(misma == 1 && matriz[Y][X] == 0){
          misma = ver_casilla(X,Y,cont,casillas );
          if((abs(matriz[y+1][x+1]) == 5 && abs(matriz[y][x]) == 1) || (abs(matriz[y+1][x+1]) == 1 && abs(matriz[y][x]) == 5) ){
            ver_coordenadas[1] = Y;
            ver_coordenadas[0] = X;
            misma = 0;
          }

        }
    }



    //Esquina contraria arriba-abajo y arriba-arriba
    if(matriz[y+1][x-1] != 0 && y+1 <= 4 && x-1 <= 0 && abs(matriz[y][x]) + abs(matriz[y+1][x+1]) <= 6 && matriz[y][x] != 0 && abs(matriz[y][x]) != 6 && x-1>= 0){

        X = x-1;
        Y = y;

        if(misma == 1 && matriz[Y][X] == 0){
          misma = ver_casilla(X,Y,cont,casillas );
          if((abs(matriz[y+1][x-1]) == 5 && abs(matriz[y][x-1]) == 1) || (abs(matriz[y+1][x-1]) == 1 && abs(matriz[y][x-1]) == 5)){
            ver_coordenadas[1] = Y;
            ver_coordenadas[0] = X;
            misma = 0;
          }

        }

        if(y+1 <=4){

        X = x;
        Y = y+1;

        if(misma == 1 && matriz[Y][X] == 0){
          misma = ver_casilla(X,Y,cont,casillas );
          if(((abs(matriz[y+1][x-1]) == 5) && (abs(matriz[y+1][x]) == 1)) || (((abs(matriz[y+1][x-1]) == 5 )&& abs(matriz[y+1][x]) == 1))){
            ver_coordenadas[1] = Y;
            ver_coordenadas[0] = X;
            misma = 0;
          }

        }
        }

    }

    //Esquina contraria abajo-abajo y arriba-arriba
    if(matriz[y-1][x+1] != 0 && y-1 >= 0 && x+1 <= 4 && abs(matriz[y][x]) + abs(matriz[y-1][x+1]) <= 6  && matriz[y][x] != 0 && abs(matriz[y][x]) != 6 && x+1 <= 4){

        X = x+1;
        Y = y;

        if(misma == 1 && matriz[Y][X] == 0){
          misma = ver_casilla(X,Y,cont,casillas );
          if((abs(matriz[y-1][x+1]) == 5 && abs(matriz[y][x+1]) == 1) || (abs(matriz[y-1][x+1]) == 0 && abs(matriz[y][x+1]) == 1) ){

            ver_coordenadas[1] = Y;
            ver_coordenadas[0] = X;
            misma = 0;
          }

        }

        if(y-1 >= 0){
        X = x;
        Y = y-1;

        if(misma == 1 && matriz[Y][X] == 0){

          misma = ver_casilla(X,Y,cont,casillas );
          if((abs(matriz[y-1][x+1]) == 5 && abs(matriz[y-1][x]) == 1) || (abs(matriz[y-1][x+1]) == 5 && abs(matriz[y-1][x]) == 1)){

            ver_coordenadas[1] = Y;
            ver_coordenadas[0] = X;
            misma = 0;
          	  }
        	}
    	}
    }
    }
  }


  if(misma == 1 && cont != 0 ){
    misma = 1;
    while(misma != 0 ){
      misma = 0;
      srand(time(NULL));
      X = rand() % 5;
      Y = rand() % 5;
      for (int i = 0; i < cont*8; i++) {
        if( Y == casillas[i*2+1] && X == casillas[i*2 + 2] && matriz[Y][X] == 0){

          misma = 1;
          break;

        }
      }
      if(misma == 1){
        srand(time(NULL));
        X = rand() % 5;
        Y = rand() % 5;
      }

      else{
        matriz[Y][X] = 1;
      }
    }
  }

  if(cont == 0 && misma == 1){
    srand(time(NULL));
    X = rand() % 5;
    Y = rand() % 5;
    while(matriz[Y][X] != 0){
      srand(time(NULL));
      X = rand() % 5;
      Y = rand() % 5;
    }
    ver_coordenadas[1] = Y;
    ver_coordenadas[0] = X;
    misma = 0;
  }

}



void principal(){

  int fin = 0;


  int acabar_juego = 0;
  int ganador[1];
  int cont;
  int casillas[160];
  if (variable == 1){
  if(color == 1){
	  c = 1;
  }
  }
  if(variable == 1){
  if(color == 2){
	  c = 2;
  }
  }
  ++variable;
    empezar = jugada_random();





  if(comp == 2){
  if( fin == 0){



  x = ver_coordenadas[0];
  y = ver_coordenadas[1];

  detectar_tip_suma();





  fin = ver_fin_juego(fin);


    if(acabar_juego == 1){
        fin = 1;
        ver_ganador(ganador);
    }

  // cambio de turno, cambio de color
  c++;

      }
    }
    if(empezar == 1 && comp == 1){
        if(empezar == 1){
            if( fin == 0){

            printf("El valor de empezar es : %d", empezar);
              x = ver_coordenadas[0];
              y = ver_coordenadas[1];

              detectar_tip_suma( );

              if(detector[0] == 0 || detector[0] == 1){
            	  suma_final();
              }



              fin = ver_fin_juego(fin);

              if (fin == 0){
              //cambio de turno y cambio de color
              ++c;


              //cambiar acabar
              cont = ver_5(casillas);
              ver_captura(cont,casillas);
              x = ver_coordenadas[0];
              y = ver_coordenadas[1];
              detectar_tip_suma_maquina( );
                            //hasta aca

              suma = detector[1];

              suma_final();



              reset_det();

              fin = ver_fin_juego(fin);
              //cambio de turno y cambio de color



                if(acabar_juego == 1){
                fin = 1;
                ver_ganador(ganador);

                    }
              }
            }
        }
    }
    if(empezar == 2 && comp == 1){
        if( fin == 0){

              //cambiar aca

              cont = ver_5(casillas);
              ver_captura(cont,casillas);
              x = ver_coordenadas[0];
              y = ver_coordenadas[1];
              detectar_tip_suma_maquina( );
              //hasta aca

              suma = detector[1];

              suma_final();


              reset_det();

              fin = ver_fin_juego(fin);
              // si ya esta el juego no se va a ejecutar lo que esta dentro del if
              if (fin == 0){

                //cambio de turno y cambio de color
              c++;


              ver_coordenadas[0] = x;
              ver_coordenadas[1] = y;



              x = ver_coordenadas[0];
              y = ver_coordenadas[1];

              detectar_tip_suma( );



              suma_final();


              reset_det(detector);
              //cambio de turno y cambio de color
              ++c;
              fin = ver_fin_juego(fin);

                if(acabar_juego == 1){
                fin = 1;


                }

                //para que imprima quien gano si es que ya se lleno el table cuando jugo la CPU
                if(acabar_juego == 1){


            }
            }
        }
    }
    if(comp == 3){
      if( fin == 0){

        //cambiar aca
    	cont = ver_5(casillas);
    	ver_captura(cont,casillas);
    	x = ver_coordenadas[0];
    	y = ver_coordenadas[1];
    	detectar_tip_suma_maquina();
    	                //hasta aca

    	suma = detector[1];

    	suma_final();


        reset_det();

    	fin = ver_fin_juego(fin);
        // si ya esta el juego no se va a ejecutar lo que esta dentro del if

        if (fin == 0){
             ++c;
             //cambiar acabar
            cont = ver_5(casillas);
            ver_captura(cont,casillas);
            x = ver_coordenadas[0];
            y = ver_coordenadas[1];
            detectar_tip_suma_maquina( );
                             //hasta aca

            suma = detector[1];

            suma_final();


            reset_det();

            fin = ver_fin_juego(fin);
            c++;


            	}
        	}
    	}

}

void input_coordenada(int valor){

	if(valor == 1){
		ver_coordenadas[1] = 0;
		ver_coordenadas[0] = 0;
	}

	if(valor == 2){
		ver_coordenadas[1] = 1;
		ver_coordenadas[0] = 0;
	}

	if(valor == 3){
		ver_coordenadas[1] = 2;
		ver_coordenadas[0] = 0;
	}

	if(valor == 4){
		ver_coordenadas[1] = 3;
		ver_coordenadas[0] = 0;
	}

	if(valor == 5){
		ver_coordenadas[1] = 4;
		ver_coordenadas[0] = 0;
	}

	if(valor == 6){
		ver_coordenadas[1] = 0;
		ver_coordenadas[0] = 1;
	}

	if(valor == 7){
		ver_coordenadas[1] = 1;
		ver_coordenadas[0] = 1;
	}

	if(valor == 8){
		ver_coordenadas[1] = 2;
		ver_coordenadas[0] = 1;
	}

	if(valor == 9){
		ver_coordenadas[1] = 3;
		ver_coordenadas[0] = 1;
	}

	if(valor == 10){
		ver_coordenadas[1] = 4;
		ver_coordenadas[0] = 1;
	}

	if(valor == 11){
		ver_coordenadas[1] = 0;
		ver_coordenadas[0] = 2;
	}

	if(valor == 12){
		ver_coordenadas[1] = 1;
		ver_coordenadas[0] = 2;
	}

	if(valor == 13){
		ver_coordenadas[1] = 2;
		ver_coordenadas[0] = 2;
	}

	if(valor == 14){
		ver_coordenadas[1] = 3;
		ver_coordenadas[0] = 2;
	}

	if(valor == 15){
		ver_coordenadas[1] = 4;
		ver_coordenadas[0] = 2;
	}

	if(valor == 16){
		ver_coordenadas[1] = 0;
		ver_coordenadas[0] = 3;
	}

	if(valor == 17){
		ver_coordenadas[1] = 1;
		ver_coordenadas[0] = 3;
	}

	if(valor == 18){
		ver_coordenadas[1] = 2;
		ver_coordenadas[0] = 3;
	}

	if(valor == 19){
		ver_coordenadas[1] = 3;
		ver_coordenadas[0] = 3;
	}

	if(valor == 20){
		ver_coordenadas[1] = 4;
		ver_coordenadas[0] = 3;
	}

	if(valor == 21){
		ver_coordenadas[1] = 0;
		ver_coordenadas[0] = 4;
	}

	if(valor == 22){
		ver_coordenadas[1] = 1;
		ver_coordenadas[0] = 4;
	}

	if(valor == 23){
		ver_coordenadas[1] = 2;
		ver_coordenadas[0] = 4;
	}

	if(valor == 24){
		ver_coordenadas[1] = 3;
		ver_coordenadas[0] = 4;
	}

	if(valor == 25){
		ver_coordenadas[1] = 4;
		ver_coordenadas[0] = 4;
	}

}

void botones_captura() {

int a;
int cant, i, j =0;
for(int i = 0; i < 12; i++){
		        printf("%d \n", detector[i]);
		    }

for( j = 1; j < detector[0]; j++){
	a =0;
	for ( i = 1; i < 12; i++) {
        if (i == detector[j]) {
            a = 1;
            break;
        }
    }
	 if(a == 0){
	  vector[cant] = detector[i];
	  ++cant;
	        }
}

}

void captura(GtkWidget *boton, gpointer *data){
	int valor = GPOINTER_TO_INT(data);
	suma = valor;
	suma_final();
}
void activar_opciones(){

	int A = 0;
	int B = 0;
	int C = 0;
	int D = 0;
	int E = 0;
	int F = 0;
	int G = 0;
	int H = 0;
	int I = 0;
	int J = 0;
	int K = 0;

	for(int i = 1; i < 12; i++){
		//Captura_Cruz
		if(1  == detector[i]){
			A = 1;
				}
		//Vacio_arriba
		if(2  == detector[i]){
			B = 1;
				}
		//Vacio_abajo
		if(3  == detector[i]){
			C = 1;
				}
		//Vacio_izquierda
		if(4  == detector[i]){
			D = 1;
				}
		//Vacio_derecha
		if(5  == detector[i]){
			E = 1;
				}
		//Vacio
		if(6  == detector[i]){
			F = 1;
				}
		if(7  == detector[i]){
			G = 1;
				}
		if(8  == detector[i]){
			H = 1;
				}
		if(9  == detector[i]){
			I = 1;
				}
		if(10  == detector[i]){
			J = 1;
				}
		if(11  == detector[i]){
			K = 1;
				}
		printf("%d \n", detector[i]);
	}



	if ( A == 0){
			gtk_widget_set_sensitive(botoncruz, FALSE);
							}

	if( B == 0){
			gtk_widget_set_sensitive(boton_vacio_arriba, FALSE);
							}

	if( C == 0){
			gtk_widget_set_sensitive(boton_vacio_abajo, FALSE);
							}

	if( D == 0){
			gtk_widget_set_sensitive(boton_vacio_izquierda, FALSE);
							}
		if( E == 0){
			gtk_widget_set_sensitive(boton_vacio_derecha, FALSE);
							}

	if( F == 0){
			gtk_widget_set_sensitive(boton_vacio_abajo_derecha, FALSE);
							}

	if( G == 0){
			gtk_widget_set_sensitive(boton_vacio_abajo_izquierda, FALSE);
							}

	if( H == 0){
			gtk_widget_set_sensitive(boton_vacio_arriba_derecha, FALSE);
							}

	if( I == 0){
			gtk_widget_set_sensitive(boton_vacio_arriba_izquierda, FALSE);
							}

	if( J == 0){
			gtk_widget_set_sensitive(boton_vacio_arriba_abajo, FALSE);
							}

	if( K == 0){
			gtk_widget_set_sensitive(boton_arriba_abajo, FALSE);
							}


	vector[0] = A;
	vector[1] = B;
	vector[2] = C;
	vector[3] = D;
	vector[4] = E;
	vector[5] = F;
	vector[6] = G;
	vector[7] = H;
	vector[8] = I;
	vector[9] = J;
	vector[10] = K;




}

void desactivar_opciones(){

	gtk_widget_set_sensitive(botoncruz, TRUE);
	gtk_widget_set_sensitive(boton_vacio_arriba, TRUE);
	gtk_widget_set_sensitive(boton_vacio_abajo, TRUE);
	gtk_widget_set_sensitive(boton_vacio_izquierda, TRUE);
	gtk_widget_set_sensitive(boton_vacio_derecha, TRUE);
	gtk_widget_set_sensitive(boton_vacio_abajo_derecha, TRUE);
	gtk_widget_set_sensitive(boton_vacio_abajo_izquierda, TRUE);
	gtk_widget_set_sensitive(boton_vacio_arriba_izquierda, TRUE);
	gtk_widget_set_sensitive(boton_vacio_arriba_derecha, TRUE);
	gtk_widget_set_sensitive(boton_vacio_arriba_abajo, TRUE);
	gtk_widget_set_sensitive(boton_arriba_abajo, TRUE);

}

void mirar_captura(GtkWidget *boton, gpointer *data){
	int valor = GPOINTER_TO_INT(data);


	if(comp == 2){

	suma = valor;

	suma_final();
	gtk_widget_set_sensitive(GTK_WIDGET(grilla_captura), FALSE);
	gtk_widget_set_sensitive(GTK_WIDGET(grid), TRUE);
	reset_det();

	casillasgtk();
	turno_boton();
	desactivar_opciones();

	}

	if(comp == 1){

		suma_final();
		gtk_widget_set_sensitive(GTK_WIDGET(grid), TRUE);
		gtk_widget_set_sensitive(GTK_WIDGET(grilla_captura), FALSE);
		reset_det();

		suma  = detector[1];
		suma_final();
		reset_det();
		casillasgtk();
		++c;



		casillasgtk();
		turno_boton();

		cont = ver_5();

		++c;

		ver_captura();

		while(matriz[y = ver_coordenadas[1]][ver_coordenadas[0]] != 0){
		ver_captura();
							}

		x = ver_coordenadas[0];
		y = ver_coordenadas[1];
		printf("Coordenadas en x = %d \n", x);
		printf("Coordenadas en y = %d \n", y);

		detectar_tip_suma();
		printf("Detector de la computadora \n");
		for(int i = 0; i < 12; ++i){

		printf("%d \n", detector[i]);
							}

		//hasta aca
		suma = detector[1];
		suma_final();
		mostrarmatriz();
		casillasgtk();
		turno_boton();
	}


}

