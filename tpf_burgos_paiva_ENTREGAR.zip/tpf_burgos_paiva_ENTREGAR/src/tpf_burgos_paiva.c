#include <gtk/gtk.h>
#include <stdio.h>
#include <time.h>
#include "globales.h"
#include "tpf_burgos_paiva2.h"



typedef struct {
    FILE* jugadora;
    FILE* jugadorb;
    int turno;
} contexto_t;


typedef struct jugador {
    char* nombre;
    int victorias;
} jugador_t;

typedef struct tabla {
    FILE* archivo;
    int capacidad;
    jugador_t* jugadores;
    int len;
} tabla_t;

//Mientras en la tabla lea dos tipos de datos va a seguir buscando la siguiente linea
void leer_tabla(tabla_t* tabla) {
    int victorias = 0;
    char nombre[255];
    while(fscanf(tabla->archivo, "%s %d \n", nombre, &victorias) == 2){
        char* str = malloc(strlen(nombre) + 1);
        strcpy(str, nombre);
        tabla->jugadores[tabla->len++] = (jugador_t){.nombre = str, .victorias = victorias};
    }
}



//abrimos el archivo en modo lectura
void cargar_tabla(tabla_t* tabla, const char* archivo) {

    tabla->capacidad = 255;
    tabla->jugadores = malloc(tabla->capacidad * sizeof(jugador_t));
    tabla->archivo = fopen(archivo, "r");
    tabla->len = 0;
    if(tabla->archivo != NULL) {
        leer_tabla(tabla);
        fclose(tabla->archivo);
        tabla->archivo = fopen(archivo, "w");
    }else {
        tabla->archivo = fopen(archivo, "w");
    }
}

void insertar_jugador(tabla_t* tabla, const char* nombre) {

    for(int i = 0; i < tabla->len; i++) {
        const char* nom = tabla->jugadores[i].nombre;
        if(strcmp(nom, nombre) == 0) {
            tabla->jugadores[i].victorias++;
            return;
        }
    }

    if(tabla->len >= tabla->capacidad) {
        tabla->jugadores = realloc(tabla->jugadores, tabla->capacidad * 2);
        if(tabla->jugadores == NULL) {
            printf("error \n");
            return;
        }
        tabla->capacidad = tabla->capacidad * 2;
    }
    char* copia = malloc(strlen(nombre) + 1);
    strcpy(copia, nombre);
    tabla->jugadores[tabla->len++] = (jugador_t){.nombre = copia, .victorias = 0};
}
void cerrar_tabla(const tabla_t* tabla) {
    for(int i = 0; i < tabla->len; i++) {
        for(int j = i; j < tabla->len; j++) {
            jugador_t* a = tabla->jugadores + i;
            jugador_t* b = tabla->jugadores + j;
            if(a->victorias < b->victorias) {
                const jugador_t aux = *a;
                *a = *b;
                *b = aux;
            }
        }
    }

    for(int i = 0; i < tabla->len; i++) {
        fprintf(tabla->archivo, "%s %d \n", tabla->jugadores[i].nombre, tabla->jugadores[i].victorias);
        free(tabla->jugadores[i].nombre);
    }
    free(tabla->jugadores);
    fclose(tabla->archivo);
}
/// Retorna -1 si no se encuentra el jugador,
int tabla_numeros_del_jugador(const tabla_t* tabla, const char* name) {
    for(int i = 0; i < tabla->len; i++) {
        const char* nom = tabla->jugadores[i].nombre;
        if(strcmp(nom, name) == 0)
            return i;

    }
    return -1;
}
void cargar_estadisticas(){
	tabla_t tabla;
	tabla_t tablaa;
	tabla_t tablap;
	cargar_tabla(&tabla, "./victorias.txt");
	cargar_tabla(&tablaa, "./derrotas.txt");
	cargar_tabla(&tablap, "./partidas_totales.txt");
	char estadisticasp[100];

	for (int i = 0; i < tabla.len; i++) {
	    sprintf(estadisticasp + strlen(estadisticasp), " %s         %d\n", tabla.jugadores[i].nombre, tabla.jugadores[i].victorias);

	    	            }
	printf("%s",estadisticasp);




	gtk_label_set_text(GTK_LABEL(estadisticas_ganador), estadisticasp);

	cerrar_tabla(&tabla);
	char estadisticasg[100];

	for (int i = 0; i < tablaa.len; i++) {
	    sprintf(estadisticasg + strlen(estadisticasg), " %s         %d\n", tablaa.jugadores[i].nombre, tablaa.jugadores[i].victorias);

		    	            }
	printf("%s",estadisticasg);

	gtk_label_set_text(GTK_LABEL(estadisticas_perdedor), estadisticasg);
	cerrar_tabla(&tablaa);




	char estadisticasc[100];

	for (int i = 0; i < tablap.len; i++) {
	    sprintf(estadisticasc + strlen(estadisticasc), " %s         %d\n", tablap.jugadores[i].nombre, tablap.jugadores[i].victorias);

		    	            }
	printf("%s",estadisticasc);

	gtk_label_set_text(GTK_LABEL(estadisticas_empate), estadisticasc);


	cerrar_tabla(&tablap);



}
void print_ganador(){
	tabla_t tabla;
	tabla_t tablaa;

	int b1;
	int b2;
    if( ganador[0] > ganador[1]){
       if(color == 1){
    	   gtk_label_set_text(GTK_LABEL(label_ganador), buffer1);

    	   cargar_tabla(&tabla, "./victorias.txt");
    	   insertar_jugador(&tabla, buffer1);
    	   cargar_tabla(&tablaa, "./derrotas.txt");
    	   insertar_jugador(&tablaa, buffer2);

    	   b1 = tabla_numeros_del_jugador(&tabla, buffer1);

    	   if(tablaa.jugadores[b1].victorias == 0){

    		   insertar_jugador(&tabla, buffer1);
    	   }
    	   b2 = tabla_numeros_del_jugador(&tablaa, buffer2);

    	   if(tablaa.jugadores[b2].victorias == 0){

    	       insertar_jugador(&tablaa, buffer2);

    	   }



       }


       else{
    	   gtk_label_set_text(GTK_LABEL(label_ganador), buffer2);
    	   cargar_tabla(&tabla, "./victorias.txt");
    	   insertar_jugador(&tabla, buffer2);
    	   cargar_tabla(&tablaa, "./derrotas.txt");
    	   insertar_jugador(&tablaa, buffer1);

    	   b2 = tabla_numeros_del_jugador(&tabla, buffer2);

    	   if(tablaa.jugadores[b2].victorias == 0){

    		   insertar_jugador(&tabla, buffer2);
    	   }
    	   b1 = tabla_numeros_del_jugador(&tablaa, buffer1);

    	   if(tablaa.jugadores[b1].victorias == 0){

    	       insertar_jugador(&tablaa, buffer1);
       }


       }

       cerrar_tabla(&tabla);
       cerrar_tabla(&tablaa);
   }

    if( ganador[1] > ganador[0] ){
    	if(color == 2){
    	    gtk_label_set_text(GTK_LABEL(label_ganador), buffer1);
    	    cargar_tabla(&tabla, "./victorias.txt");
    	    insertar_jugador(&tabla, buffer1);
    	    cargar_tabla(&tablaa, "./derrotas.txt");
    	    insertar_jugador(&tablaa, buffer2);

    	    b1 = tabla_numeros_del_jugador(&tabla, buffer1);

     	   if(tablaa.jugadores[b1].victorias == 0){

     		   insertar_jugador(&tabla, buffer1);
     	   }
     	   b2 = tabla_numeros_del_jugador(&tablaa, buffer2);

     	   if(tablaa.jugadores[b2].victorias == 0){

     	       insertar_jugador(&tablaa, buffer2);
     	   }
    	}


    	else{
    	    gtk_label_set_text(GTK_LABEL(label_ganador), buffer2);
    	    cargar_tabla(&tabla, "./victorias.txt");
    	    insertar_jugador(&tabla, buffer2);
    	    cargar_tabla(&tablaa, "./derrotas.txt");
    	    insertar_jugador(&tablaa, buffer1);

    	    b2 = tabla_numeros_del_jugador(&tabla, buffer2);

     	    if(tablaa.jugadores[b2].victorias == 0){

     		   insertar_jugador(&tabla, buffer2);
     	   }
     	    b1 = tabla_numeros_del_jugador(&tablaa, buffer1);

     	   if(tablaa.jugadores[b1].victorias == 0){

     	       insertar_jugador(&tablaa, buffer1);

    	}

    }

        cerrar_tabla(&tabla);
        cerrar_tabla(&tablaa);
   }

    if( ganador[0] == ganador[1] ){
    	gtk_label_set_text(GTK_LABEL(label_ganador), "Nadie!");

    }




    tabla_t tablap;
    int b3,b4;
    cargar_tabla(&tablap, "./partidas_totales.txt");
    insertar_jugador(&tablap, buffer1);


    b3 = tabla_numeros_del_jugador(&tablap, buffer1);

    if(tablap.jugadores[b3].victorias == 0){

      		   insertar_jugador(&tablap, buffer1);
      	   }


    cerrar_tabla(&tablap);
    cargar_tabla(&tablap, "./partidas_totales.txt");
    insertar_jugador(&tablap, buffer2);
    b4 = tabla_numeros_del_jugador(&tablap, buffer2);

    if(tablap.jugadores[b4].victorias == 0){

      	       insertar_jugador(&tablap, buffer2);

      	   }



    cerrar_tabla(&tablap);


}



void openwindow(GtkWidget *widget, gpointer user_data) {	//abre una y cierra la otra
	//if(comprobarconfig())
	// Ocultar la ventana que contiene el botón presionado
	    gtk_widget_hide(gtk_widget_get_toplevel(widget));

	    // Mostrar la ventana que recibió como parámetro
	    gtk_widget_show_all(GTK_WIDGET(user_data));
	//else
	    //mostrar dialog box warning debe configurar la partida


}

void openwindow7(GtkWidget *widget, gpointer user_data) {	//abre una y cierra la otra
	//if(comprobarconfig())
	// Ocultar la ventana que contiene el botón presionado
	    gtk_widget_hide(gtk_widget_get_toplevel(widget));

	    // Mostrar la ventana que recibió como parámetro
	    gtk_widget_show_all(GTK_WIDGET(user_data));
	    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botoncvj),FALSE);
	    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonjvj),FALSE);
	    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botoncvc),FALSE);

	    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonrojo),FALSE);
	    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botoncal),FALSE);
	    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonazul),FALSE);

	    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonemp2),FALSE);
	    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botoneal),FALSE);
	    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonemp1),FALSE);



	//else
	    //mostrar dialog box warning debe configurar la partida
	    comp = 0;
	    color = 0;
	    empezar = 0;
}

void terminar_programa(GtkWidget *widget, gpointer data) {
    // Salir del bucle principal de eventos
    gtk_main_quit();
}
//configuracion de los botones

void configuracionmodo1(GtkToggleButton  *boton, gpointer data){	//modo jugador contra ia

	if (gtk_toggle_button_get_active(boton)){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonjvj),FALSE);//se desactiva jvj
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botoncvc),FALSE);
		comp=1;
	}

	if(comp == 1){

	}
}
void configuracionmodo2(GtkToggleButton  *boton, gpointer data){ // modo jugador contra juador

	if (gtk_toggle_button_get_active(boton)){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botoncvj),FALSE);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botoncvc),FALSE);
		comp=2;
	}


}
void configuracionmodo3(GtkToggleButton  *boton, gpointer data){ // modo jugador contra juador

	if (gtk_toggle_button_get_active(boton)){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botoncvj),FALSE);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonjvj),FALSE);//se desactiva jvj
		comp=3;
	}
}


//funciones que elige colores
void configuracioncolor1(GtkToggleButton  *boton, gpointer data){
	color=1;
	if (gtk_toggle_button_get_active(boton)){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonrojo),FALSE);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botoncal),FALSE);

	}
}
void configuracioncolor2(GtkToggleButton  *boton, gpointer data){
	color=2;
	if (gtk_toggle_button_get_active(boton)){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonazul),FALSE);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botoncal),FALSE);

	}
}
void configuracioncolor3(GtkToggleButton  *boton, gpointer data){

	if (gtk_toggle_button_get_active(boton)){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonazul),FALSE);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonrojo),FALSE);
		srand(time(NULL));
		color=rand() % 3;
	}
}
//funciones que elige  quien empieza
void configuracionemp1(GtkToggleButton  *boton, gpointer data){

	if (gtk_toggle_button_get_active(boton)){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonemp2),FALSE);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botoneal),FALSE);
		empezar=1;
	}
}
void configuracionemp2(GtkToggleButton  *boton, gpointer data){

	if (gtk_toggle_button_get_active(boton)){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonemp1),FALSE);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botoneal),FALSE);
		empezar=2;
	}
}
void configuracionemp3(GtkToggleButton  *boton, gpointer data){

	if (gtk_toggle_button_get_active(boton)){
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonemp2),FALSE);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(botonemp1),FALSE);
		srand(time(NULL));
		empezar=rand() % 3;
	}
}
void continuar (GtkWidget *windget, gpointer user_data){
	if (comp!=0 && empezar!=0 && color!=0){


		 gtk_widget_hide(gtk_widget_get_toplevel(windget));

			    // Mostrar la ventana que recibió como parámetro
		gtk_widget_show_all(GTK_WIDGET(user_data));
	}
}

void guardar_nombre(){

	if(comp == 2){

	    const gchar *texto1 = gtk_entry_get_text(GTK_ENTRY(entry1));
	    const gchar *texto2 = gtk_entry_get_text(GTK_ENTRY(entry2));
	    snprintf(buffer1, sizeof(buffer1),"%s",texto1);
	    snprintf(buffer2, sizeof(buffer2),"%s",texto2);
	    // Hacer algo con el texto (en este caso, imprimirlo)
	    printf("Texto ingresado: %s\n", buffer1);
	    printf("Texto ingresado: %s\n", buffer2);
	    gtk_label_set_text(GTK_LABEL(nombre1), buffer1);
	    gtk_label_set_text(GTK_LABEL(nombre2), buffer2);

	}


	if(comp == 1){

		const gchar *texto1 = gtk_entry_get_text(GTK_ENTRY(entry1));
		snprintf(buffer1, sizeof(buffer1),"%s",texto1);

		strcpy(buffer2 , "C-phalopod");
		gtk_label_set_text(GTK_LABEL(nombre1), buffer1);
	    gtk_label_set_text(GTK_LABEL(nombre2), buffer2);

	}

	if(comp == 3){


	   snprintf(buffer1, sizeof(buffer1),"%s",texto1);
	   strcpy(buffer1 , "C-phalopod");
	   strcpy(buffer2 , "Skylinex");
				    // Hacer algo con el texto (en este caso, imprimirlo)

	   gtk_label_set_text(GTK_LABEL(nombre1), buffer1);
	   gtk_label_set_text(GTK_LABEL(nombre2), buffer2);

		}

}





//conecta lo seleccionado con el codigo de juego
void inicio_juego(){

	mostrarmatriz();

	int final = 0;
	printf("El valor de color es : ");
	 printf("%d \n ",comp);
	 if (variable == 1){
		 if(color == 1){
	 			c = 1;

	 	 }
	 }
	 if(variable == 1){
	 	if(color == 2){
	 		c = 2;

	 	}



	 }
	 turno_boton();

 //mandar configuraciones
	 if(color !=0 && comp!=0 && empezar!=0){


	 if(comp == 1){
		 if(empezar == 2){

		 ++variable;
		 cont = ver_5();


			 		ver_captura();

			 		while(matriz[y = ver_coordenadas[1]][ver_coordenadas[0]] != 0){
			 			ver_captura();
			 		}

			 		x = ver_coordenadas[0];
			 		y = ver_coordenadas[1];


			 		detectar_tip_suma();
			 		suma = detector[1];
			 		suma_final();
			 		mostrarmatriz();
			 		casillasgtk();
			 		++c;

		 }
	 }



	 if(comp == 3){

	 		 for(int i = 0; i < 50; i++ ){

	 		cont = ver_5();
	 		ver_captura();

	 		x = ver_coordenadas[0];
	 		y = ver_coordenadas[1];


	 		detectar_tip_suma();
	 		suma = detector[1];
	 		suma_final();

	 		++c;
	 		final = ver_fin_juego(final);

	 		 }

	 	 }
	 gtk_widget_set_sensitive(GTK_WIDGET(grilla_captura), FALSE);
	 casillasgtk();
	 gtk_widget_hide(windowconf);
	 gtk_widget_show_all(windowjuego);
	 gtk_label_set_text(GTK_LABEL(nombre1),texto1);

	 }








}


void presionar(GtkWidget *boton, gpointer *data){


	reset_det();


	int valor = GPOINTER_TO_INT(data);

	if(comp == 2){
	input_coordenada(valor);
	if(matriz[ver_coordenadas[1]][ver_coordenadas[0]] == 0){

	principal();

	}
	if(detector[0] <= 1 ){


		 suma = detector[1];
		 suma_final();
		 mostrarmatriz();
		 reset_det();

		}


		if(detector[0] > 1){

		gtk_widget_set_sensitive(GTK_WIDGET(grilla_captura), TRUE);
		gtk_widget_set_sensitive(GTK_WIDGET(grid), FALSE);
		activar_opciones();
	    }
		casillasgtk();

	}


	if(comp == 1){
		if(empezar == 1 || empezar == 2){

			input_coordenada(valor);


			detectar_tip_suma();

			if(matriz[ver_coordenadas[1]][ver_coordenadas[0]] == 0){
				if(detector[0] == 0 || detector[0] == 1){




					++variable;
					x = ver_coordenadas[0];
					y = ver_coordenadas[1];

					detectar_tip_suma();
					suma  = detector[1];
					suma_final();
					reset_det();
					casillasgtk();

					++c;
					cont = ver_5();



					ver_captura();

					while(matriz[y = ver_coordenadas[1]][ver_coordenadas[0]] != 0){
						ver_captura();
					}

					x = ver_coordenadas[0];
					y = ver_coordenadas[1];

					detectar_tip_suma();

					//hasta aca

					suma = detector[1];
					suma_final();
					casillasgtk();
					++c;


				}

				else{

					gtk_widget_set_sensitive(GTK_WIDGET(grilla_captura), TRUE);
					activar_opciones();
					gtk_widget_set_sensitive(GTK_WIDGET(grid), FALSE);





								    }
				casillasgtk();

			}


		}
	}

	turno_boton();


}


int main(int argc, char *argv[]) {

	     // Inicialización de GTK
	   gtk_init(&argc, &argv);

	   GtkBuilder  *constructor = gtk_builder_new_from_file("tpf_burgos_paiva.glade");

	     if (constructor == NULL) {
	         printf("Error al cargar el archivo Glade\n");
	         return 1; // Salir con error
	     }


	     estadisticas_ganador=GTK_LABEL(gtk_builder_get_object(constructor, "estadisticas")) ;
	     estadisticas_perdedor=GTK_LABEL(gtk_builder_get_object(constructor, "estadisticas1")) ;
	     estadisticas_empate=GTK_LABEL(gtk_builder_get_object(constructor, "estadisticas2")) ;
 	     grilla_captura=GTK_GRID(gtk_builder_get_object(constructor, "grid_captura"));
 	     grid=GTK_GRID(gtk_builder_get_object(constructor, "grilla_tablero"));
	     botoncruz = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_cruz"));
	     boton_vacio_arriba = GTK_WIDGET(gtk_builder_get_object(constructor, "auto_abajo"));
	     boton_vacio_abajo = GTK_WIDGET(gtk_builder_get_object(constructor, "auto_arriba"));
	     boton_vacio_izquierda = GTK_WIDGET(gtk_builder_get_object(constructor, "auto_derecha"));
	     boton_vacio_derecha = GTK_WIDGET(gtk_builder_get_object(constructor, "auto_izquierda"));
	     boton_vacio_abajo_derecha = GTK_WIDGET(gtk_builder_get_object(constructor, "arriba_izquierda"));
	     boton_vacio_abajo_izquierda = GTK_WIDGET(gtk_builder_get_object(constructor, "arriba_derecha"));
	     boton_vacio_arriba_izquierda = GTK_WIDGET(gtk_builder_get_object(constructor, "bajo_derecha"));
	     boton_vacio_arriba_derecha= GTK_WIDGET(gtk_builder_get_object(constructor, "abajo_izquierda"));
	     boton_vacio_arriba_abajo= GTK_WIDGET(gtk_builder_get_object(constructor, "izquierda_derecha"));
	     boton_arriba_abajo= GTK_WIDGET(gtk_builder_get_object(constructor, "arriba_abajo"));

	     entry1= GTK_ENTRY(gtk_builder_get_object(constructor, "entry1"));
	     entry2= GTK_ENTRY(gtk_builder_get_object(constructor, "entry2"));


	     // Obtener objetos de las ventanas y botones
	     GtkWidget *windowinicial = GTK_WIDGET(gtk_builder_get_object(constructor, "ventana_inicial"));
	     GtkWidget *windowcreditos = GTK_WIDGET(gtk_builder_get_object(constructor, "ventana_creditos"));
	     windowjuego = GTK_WIDGET(gtk_builder_get_object(constructor, "ventana_juego"));
	     GtkWidget *windowacerca = GTK_WIDGET(gtk_builder_get_object(constructor, "ventana_acerca"));
	     windowconf = GTK_WIDGET(gtk_builder_get_object(constructor, "ventana_configuracion"));
	     GtkWidget *windowestadistic = GTK_WIDGET(gtk_builder_get_object(constructor, "ventana_estadistic_vic"));
	     windowganador = GTK_WIDGET(gtk_builder_get_object(constructor, "ventana_ganador"));
	     boton_salir2 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_salir2"));
	     boton_jugar_3 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_jugar_3"));



	     GtkWidget *botonjugar = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_jugar"));
	     GtkWidget *botoncreditos = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_creditos"));
	     GtkWidget *botonacerca = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_acerca"));
	     GtkWidget *botonestadistica = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_estadisticas"));
	     GtkWidget *botonjugar2 = GTK_WIDGET(gtk_builder_get_object(constructor, "botonjugar2"));
	     boton_continuar= GTK_WIDGET(gtk_builder_get_object(constructor, "boton_continuar"));
	     boton_terminar= GTK_WIDGET(gtk_builder_get_object(constructor, "boton_fin"));
	     boton_salir=GTK_WIDGET(gtk_builder_get_object(constructor, "boton_salir"));
	     boton_continuar= GTK_WIDGET(gtk_builder_get_object(constructor, "boton_continuar"));
	     botonrojo = GTK_TOGGLE_BUTTON(gtk_builder_get_object(constructor, "botonrojo"));
	     botonjvj=GTK_TOGGLE_BUTTON(gtk_builder_get_object(constructor, "botonjvj"));
	     botoncvc=GTK_TOGGLE_BUTTON(gtk_builder_get_object(constructor, "botoncvc"));
	     botoncvj=GTK_TOGGLE_BUTTON(gtk_builder_get_object(constructor, "botoncvj"));
	     botonazul=GTK_TOGGLE_BUTTON(gtk_builder_get_object(constructor, "botonazul"));
	     botoncal=GTK_TOGGLE_BUTTON(gtk_builder_get_object(constructor, "botoncal"));
	     botonemp1=GTK_TOGGLE_BUTTON(gtk_builder_get_object(constructor, "botonej1"));
	     botonemp2=GTK_TOGGLE_BUTTON(gtk_builder_get_object(constructor, "botonej2"));
	     botoneal=GTK_TOGGLE_BUTTON(gtk_builder_get_object(constructor, "botonea"));
	     boton_turno = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_turno"));
	     nombre1=GTK_LABEL(gtk_builder_get_object(constructor, "nombre_tablero_1"));
	     nombre2=GTK_LABEL(gtk_builder_get_object(constructor, "nombre_tablero_2"));
	     label_ganador=GTK_LABEL(gtk_builder_get_object(constructor, "label_ganador"));
	     label_estadisticas=GTK_LABEL(gtk_builder_get_object(constructor, "estadisticas"));
	     GtkWidget *botonvolver1 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_volver1"));
	     GtkWidget *botonvolver2 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_volver2"));
	     GtkWidget *botonvolver3 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_volver3"));
	     GtkWidget *botonvolver5 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_volver5"));
	     GtkWidget *botonvolver6 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_volver6"));
	     GtkWidget *botonvolver7 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_volver7"));
	     BOTON1 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_1"));
	     BOTON2 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_2"));
	     BOTON3 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_3"));
	     BOTON4 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_4"));
	     BOTON5 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_5"));
	     	     BOTON6 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_6"));
	     	     BOTON7 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_7"));
	     	     BOTON8 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_8"));
	     	     BOTON9 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_9"));
	     	     BOTON10 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_10"));
	     	     BOTON11 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_11"));
	     	     BOTON12 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_12"));
	     	     BOTON13 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_13"));
	     	     BOTON14 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_14"));
	     	     BOTON15 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_15"));
	     	     BOTON16 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_16"));
	     	     BOTON17 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_17"));
	     	     BOTON18 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_18"));
	     	     BOTON19 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_19"));
	     	     BOTON20 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_20"));
	     	     BOTON21 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_21"));
	     	     BOTON22 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_22"));
	     	     BOTON23 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_23"));
	     	     BOTON24 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_24"));
	     	     BOTON25 = GTK_WIDGET(gtk_builder_get_object(constructor, "boton_tablero_25"));



	 //conexion d los botones para cambiar ventanas
	     g_signal_connect(botonjugar, "clicked", G_CALLBACK(openwindow), windowconf);
	     g_signal_connect(botoncreditos, "clicked", G_CALLBACK(openwindow), windowcreditos);
	     g_signal_connect(botonacerca, "clicked", G_CALLBACK(openwindow), windowacerca);
	     g_signal_connect(botonestadistica, "clicked", G_CALLBACK(cargar_estadisticas), windowestadistic);
	     g_signal_connect(botonestadistica, "clicked", G_CALLBACK(openwindow), windowestadistic);
	     g_signal_connect(botonjugar2, "clicked", G_CALLBACK(inicio_juego), windowjuego);

	     g_signal_connect(boton_continuar, "clicked", G_CALLBACK(continuar), windowjuego);

	     g_signal_connect(botonjugar2, "clicked", G_CALLBACK(guardar_nombre), entry1);
	     g_signal_connect(boton_terminar, "clicked", G_CALLBACK(openwindow), windowganador);
	     g_signal_connect(boton_terminar, "clicked", G_CALLBACK(ver_ganador), NULL);
	     g_signal_connect(boton_terminar, "clicked", G_CALLBACK(print_ganador), NULL);
	     g_signal_connect(boton_terminar, "clicked", G_CALLBACK(cargar_estadisticas), NULL);

	     g_signal_connect(boton_salir, "clicked", G_CALLBACK(terminar_programa), GINT_TO_POINTER(1));
	     g_signal_connect(boton_salir2, "clicked", G_CALLBACK(terminar_programa), GINT_TO_POINTER(2));

	 //opcion para volver
	     g_signal_connect(botonvolver1, "clicked", G_CALLBACK(openwindow), windowinicial);
	     g_signal_connect(botonvolver2, "clicked", G_CALLBACK(openwindow), windowinicial);
	     g_signal_connect(botonvolver3, "clicked", G_CALLBACK(openwindow), windowinicial);

	     g_signal_connect(botonvolver5, "clicked", G_CALLBACK(openwindow), windowinicial);
	     g_signal_connect(botonvolver6, "clicked", G_CALLBACK(openwindow), windowinicial);
	     g_signal_connect(botonvolver7, "clicked", G_CALLBACK(openwindow7), windowinicial);

	 //prepara la configuracion del juego
	     g_signal_connect(botonazul, "toggled", G_CALLBACK(configuracioncolor1), windowconf );
	     g_signal_connect(botonrojo, "toggled", G_CALLBACK(configuracioncolor2), windowconf );
	     g_signal_connect(botoncal, "toggled", G_CALLBACK(configuracioncolor3), windowconf );
	     g_signal_connect(botonjvj, "toggled", G_CALLBACK(configuracionmodo2), windowconf );
	     g_signal_connect(botoncvj, "toggled", G_CALLBACK(configuracionmodo1), windowconf );
	     g_signal_connect(botonemp1, "toggled", G_CALLBACK(configuracionemp1), windowconf );
	     g_signal_connect(botonemp2, "toggled", G_CALLBACK(configuracionemp2), windowconf );
	     g_signal_connect(botoneal, "toggled", G_CALLBACK(configuracionemp3), windowconf );
	     g_signal_connect(botoncvc, "toggled", G_CALLBACK(configuracionmodo3), windowconf );
// designacion de los botones del tablero




	     inicializarmatriz();
	     casillasgtk();


	     g_signal_connect(BOTON1, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(1));
	     g_signal_connect(BOTON2, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(2));
	     g_signal_connect(BOTON3, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(3));
	     g_signal_connect(BOTON4, "clicked", G_CALLBACK(presionar),GINT_TO_POINTER(4));
	     g_signal_connect(BOTON5, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(5));
	     g_signal_connect(BOTON6, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(6));
	     g_signal_connect(BOTON7, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(7));
	     g_signal_connect(BOTON8, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(8));
	     g_signal_connect(BOTON9, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(9));
	     g_signal_connect(BOTON10, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(10));
	     g_signal_connect(BOTON11, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(11));
	     g_signal_connect(BOTON12, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(12));
	     g_signal_connect(BOTON13, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(13));
	     g_signal_connect(BOTON14, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(14));
	     g_signal_connect(BOTON15, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(15));
	     g_signal_connect(BOTON16, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(16));
	     g_signal_connect(BOTON17, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(17));
	     g_signal_connect(BOTON18, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(18));
	     g_signal_connect(BOTON19, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(19));
	     g_signal_connect(BOTON20, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(20));
	     g_signal_connect(BOTON21, "clicked", G_CALLBACK(presionar),GINT_TO_POINTER(21));
	     g_signal_connect(BOTON22, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(22));
	     g_signal_connect(BOTON23, "clicked", G_CALLBACK(presionar),GINT_TO_POINTER(23));
	     g_signal_connect(BOTON24, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(24));
	     g_signal_connect(BOTON25, "clicked", G_CALLBACK(presionar), GINT_TO_POINTER(25));
	     //apagar grilla




	     	 	//botones captura


	     g_signal_connect(botoncruz, "clicked", G_CALLBACK(mirar_captura), GINT_TO_POINTER(1) );
	     g_signal_connect(boton_vacio_arriba, "clicked", G_CALLBACK(mirar_captura), GINT_TO_POINTER(2));
	     g_signal_connect(boton_vacio_abajo, "clicked", G_CALLBACK(mirar_captura), GINT_TO_POINTER(3));
	     g_signal_connect(boton_vacio_izquierda, "clicked", G_CALLBACK(mirar_captura),GINT_TO_POINTER(4));
	     g_signal_connect(boton_vacio_derecha, "clicked", G_CALLBACK(mirar_captura), GINT_TO_POINTER(5));
	     g_signal_connect(boton_vacio_abajo_derecha, "clicked", G_CALLBACK(mirar_captura), GINT_TO_POINTER(6));
	     g_signal_connect(boton_vacio_abajo_izquierda, "clicked", G_CALLBACK(mirar_captura), GINT_TO_POINTER(7)); //poaible
	     g_signal_connect(boton_vacio_arriba_izquierda, "clicked", G_CALLBACK(mirar_captura), GINT_TO_POINTER(8)); // error
	     g_signal_connect(boton_vacio_arriba_derecha, "clicked", G_CALLBACK(mirar_captura), GINT_TO_POINTER(9)); // error
	     g_signal_connect(boton_vacio_arriba_abajo, "clicked", G_CALLBACK(mirar_captura), GINT_TO_POINTER(10));
	     g_signal_connect(boton_arriba_abajo, "clicked", G_CALLBACK(mirar_captura), GINT_TO_POINTER(11));





	     gtk_widget_show_all(windowinicial);

	     // Ejecutar el bucle principal de GTK
	     gtk_main();



	     return 0; // Termina el programa sin errores

	 }



