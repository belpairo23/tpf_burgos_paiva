

#ifndef GLOBALES_H_
#define GLOBALES_H_


extern GtkGrid *grid;  // Declarar el Grid globalmente
#define azul 1
#define rojo 0
#define al 4
#define pvp 5
#define pvc 6
#define emp1
extern int opcion;
extern int suma;
extern int c;
extern int variable;
extern int x;
extern int y;
extern int a;
extern int cont;
extern int casillas[160];
extern int color;
extern int control;
extern int comp;
extern int empezar;
extern int matriz[10][10];
extern int detector[12];
extern int ver_coordenadas[2];
extern int vector[12];
extern int ganador[1];
extern char buffer1[50];
extern char buffer2[50];
extern GtkWidget *windowinicial;
extern GtkBuilder *constructor;
extern GtkWidget *windowganador;
extern const gchar *texto1;
extern const gchar *texto2;
//ventana incial
extern GtkWidget *boton_salir;
extern GtkWidget *botonacerca;
extern	GtkWidget *botoncreditos;
	extern	GtkWidget *botonjugar;
	extern	GtkWidget *boton_continuar;
	extern GtkWidget *boton_salir2;
extern GtkLabel *label_ganador;
extern GtkLabel *label_estadisticas;


//ventana creditos
	extern	GtkWidget  *windowcreditos;
	extern	GtkWidget  *botonvolver3;


//ventana acerca

	extern	GtkWidget *windowacerca;
	extern	GtkWidget *botonvolver1;

	extern	GtkWidget *botonestadistica;

	//ventana configuracion
	extern	GtkWidget  *windowconf;
	extern	GtkWidget  *botonvolver2;
	extern	GtkToggleButton  *botonjvj;
	extern	GtkToggleButton  *botoncvj;
	extern	GtkWidget  *botonjugar2;
	extern	GtkToggleButton  *botonrojo	;
	extern	GtkToggleButton  *botonazul;
	extern	GtkToggleButton  *botoncal;
	extern	GtkToggleButton  *botonemp1	;
	extern	GtkToggleButton  *botonemp2;
	extern	GtkToggleButton *botoneal;
	extern	GtkLabel *nombre2;
	extern  GtkLabel *nombre1;
	extern  GtkLabel *estadisticas_ganador;
	extern  GtkLabel *estadisticas_empate;
    extern  GtkWidget *boton_turno;
    extern  GtkEntry *entry1;
    extern  GtkEntry *entry2;
    extern  GtkLabel *estadisticas_perdedor;
 extern   GtkToggleButton  *botoncvc;
	//ventana juego

    extern	GtkWidget  *windowjuego;
	extern	GtkWidget *botonvolver5;
	extern	GtkWidget *botoncruz;
	extern	GtkWidget *boton_vacio_arriba;
	extern	GtkWidget *boton_vacio_abajo;
	extern	GtkWidget *boton_vacio_izquierda;
	extern	GtkWidget *boton_vacio_derecha;
	extern	GtkWidget *boton_vacio_abajo_derecha;
	extern	GtkWidget *boton_vacio_abajo_izquierda;
	extern	GtkWidget *boton_vacio_arriba_izquierda;
	extern	GtkWidget *boton_vacio_arriba_derecha;
	extern	GtkWidget *boton_vacio_arriba_abajo;
	extern	GtkWidget *boton_arriba_abajo;
	extern	GtkWidget  *BOTON1;
	extern  GtkWidget *BOTON2;
	extern	GtkWidget *BOTON3;
	extern	GtkWidget *BOTON4;
	extern	GtkWidget *BOTON5;
	extern	GtkWidget *BOTON6;
	extern  GtkWidget *BOTON7;
	extern	GtkWidget *BOTON8;
	extern GtkWidget *BOTON9;
	extern	GtkWidget *BOTON10;
	extern	GtkWidget *BOTON11;
	extern GtkWidget *BOTON12;
    extern GtkWidget *BOTON13;
	extern GtkWidget *BOTON14;
	extern	GtkWidget  *BOTON15;
	extern	GtkWidget  *BOTON16;
	extern	GtkWidget  *BOTON17;
	extern	GtkWidget	*BOTON18;
	extern	GtkWidget *BOTON19;
	extern	GtkWidget *BOTON20;
	extern	GtkWidget *BOTON21;
	extern	GtkWidget *BOTON22;
	extern	GtkWidget *BOTON23;
	extern	GtkWidget *BOTON24;
	extern   GtkWidget	*BOTON25;
    extern	 GtkWidget *text1;
	extern GtkWidget *text3;
	extern	GtkWidget *text2;
	extern GtkGrid *grilla_captura;

	extern	GtkWidget *boton_terminar;
	extern	GtkWidget *boton_jugar_3;


	//ventana estadistica
	extern	GtkWidget *windowestadistic;
extern	GtkWidget *botonvolver6;
extern GtkWidget *botonvolver7;






#endif /* GLOBALES_H_ */
